"# KeralaAgriRAG" 
step1 : - create data/pdf directory inside pdf folder put all the pddf files as data
step2 : - in .env file replace your api key
