# app.py
import streamlit as st
import requests

st.set_page_config(page_title="RAG Query App", page_icon="🧠", layout="centered")

st.title("🧠 RAG Knowledge Assistant")
st.markdown("Ask any question from your PDF knowledge base!")

# Backend endpoint
API_URL = "http://127.0.0.1:8000/query"

# Input
query = st.text_area("Enter your query:", placeholder="e.g., What is Brown leaf spot and how to control it?")
top_k = st.slider("Top K Documents", 1, 10, 3)
summarize = st.checkbox("Summarize the answer", value=True)

if st.button("Ask"):
    if not query.strip():
        st.warning("Please enter a query.")
    else:
        with st.spinner("Fetching answer... ⏳"):
            payload = {
                "question": query,
                "top_k": top_k,
                "summarize": summarize,
                "min_score": 0.1
            }
            try:
                response = requests.post(API_URL, json=payload)
                if response.status_code == 200:
                    data = response.json()
                    st.success("✅ Answer retrieved!")

                    st.subheader("📘 Answer")
                    st.write(data["answer"])

                    if data["summary"]:
                        st.subheader("📝 Summary")
                        st.write(data["summary"])

                    st.subheader("📜 Last Query History")
                    st.json(data["history"][-1])

                else:
                    st.error(f"Error: {response.status_code} - {response.text}")
            except Exception as e:
                st.error(f"Failed to connect to API: {e}")
