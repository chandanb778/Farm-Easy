# rag_api.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Import your RAG classes
from pdf_loader import AdvancedRAGPipeline, rag_retriever, llm

app = FastAPI()

# Enable CORS (so Streamlit frontend can call it)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize RAG pipeline
adv_rag = AdvancedRAGPipeline(rag_retriever, llm)

# Input schema
class QueryRequest(BaseModel):
    question: str
    top_k: int = 3
    min_score: float = 0.1
    summarize: bool = True

@app.post("/query")
async def query_rag(request: QueryRequest):
    result = adv_rag.query(
        request.question,
        top_k=request.top_k,
        min_score=request.min_score,
        stream=False,
        summarize=request.summarize
    )

    return {
        "answer": result["answer"],
        "summary": result["summary"],
        "history": result["history"],
    }

# Run with: uvicorn rag_api:app --reload --port 8000
